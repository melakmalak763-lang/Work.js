import { randomBytes } from "node:crypto";
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
function makeKey(n=400) {
  const bytes = randomBytes(n);
  let s = "";
  for (let i=0;i<n;i++) s += alphabet[bytes[i] % alphabet.length];
  return s;
}
const keys = Array.from({length:20},()=>makeKey());
keys.forEach((k,i)=>console.log(`gate:${i+1}=${k}`));
console.log("\nاحتفظ بالمفاتيح بسرية. انسخ كل قيمة إلى KV تحت المفتاح gate:1 ... gate:20 بالترتيب.");
