const HTML_GATE = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TRO Protected</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1120;color:#eef2ff;font-family:system-ui,Arial;padding:20px}.card{max-width:520px;width:100%;padding:34px;border:1px solid #26334b;border-radius:22px;background:#111b2e;text-align:center;box-shadow:0 20px 70px #0005}.logo{font-size:14px;letter-spacing:4px;color:#7db6ff}.icon{font-size:54px;margin:20px 0 8px}h1{margin:8px 0 12px;font-size:28px}p{color:#b8c4d9;line-height:1.8}.track{height:7px;border-radius:9px;background:#26334b;overflow:hidden;margin:26px 0 12px}.bar{height:100%;width:0;background:#60a5fa;animation:load 10s linear forwards}@keyframes load{to{width:100%}}.small{font-size:12px;color:#8190a8}</style><body><main class="card"><div class="logo">TRO SECURITY</div><div class="icon">🔒</div><h1>رابط محمي بواسطة TRO</h1><p>سيتم نقلك إلى صفحة التحقق بعد <strong id="seconds">10</strong> ثوانٍ.</p><div class="track"><div class="bar"></div></div><div class="small">TRO SECURITY SYSTEM</div></main><script>let n=10;const el=document.getElementById('seconds');const timer=setInterval(()=>{n--;el.textContent=n;if(n<=0){clearInterval(timer);location.replace('/unlock')}},1000)</script></body></html>`;

const HTML_UNLOCK = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TRO Unlock</title><style>
*{box-sizing:border-box}body{margin:0;background:#0b1120;color:#eef2ff;font-family:system-ui,Arial;padding:22px}.wrap{max-width:760px;margin:25px auto}.card{background:#111b2e;border:1px solid #26334b;border-radius:20px;padding:24px}.logo{color:#7db6ff;letter-spacing:3px;font-size:13px}h1{margin:10px 0}p{color:#b8c4d9;line-height:1.8}.field{margin:16px 0}label{display:block;margin-bottom:8px;color:#d8e2f2}input,textarea{width:100%;background:#0b1120;color:#eef2ff;border:1px solid #34445f;border-radius:10px;padding:12px;font:inherit}textarea{min-height:85px;resize:vertical;direction:ltr}button{border:0;border-radius:11px;background:#3b82f6;color:white;padding:13px 18px;font:inherit;font-weight:700;cursor:pointer;width:100%;margin-top:12px}.hint{font-size:12px;color:#93a4bd}.status{margin-top:15px;white-space:pre-wrap;overflow-wrap:anywhere}.success{color:#86efac}.error{color:#fca5a5}a{color:#93c5fd;overflow-wrap:anywhere}.keygrid{display:grid;grid-template-columns:1fr;gap:10px}@media(min-width:650px){.keygrid{grid-template-columns:1fr 1fr}}</style><body><main class="wrap"><section class="card"><div class="logo">TRO API • SECURE ACCESS</div><h1>فتح الرابط المحمي</h1><p>أدخل كلمة المرور ذات 30 حرفاً والمفاتيح العشرين. التحقق يتم على السيرفر.</p><form id="form"><div class="field"><label for="password">كلمة المرور (30 حرفاً)</label><input id="password" minlength="30" maxlength="30" required autocomplete="off" placeholder="30 حرفاً بالضبط"><div class="hint"><span id="count">0</span>/30</div></div><h3>مفاتيح الوصول (20 مفتاحاً، كل واحد 400 حرف)</h3><div id="keys" class="keygrid"></div><button id="submit" type="submit">التحقق وإظهار رابط Raw</button></form><div id="status" class="status"></div></section></main><script>
const box=document.getElementById('keys');for(let i=1;i<=20;i++){const d=document.createElement('div');d.className='field';const l=document.createElement('label');l.textContent='المفتاح '+i+' (400 حرف)';const t=document.createElement('textarea');t.maxLength=400;t.minLength=400;t.required=true;t.autocomplete='off';t.spellcheck=false;t.placeholder='الصق المفتاح '+i;d.append(l,t);box.append(d)}
const pass=document.getElementById('password');pass.addEventListener('input',()=>document.getElementById('count').textContent=pass.value.length);
document.getElementById('form').addEventListener('submit',async e=>{e.preventDefault();const status=document.getElementById('status'),btn=document.getElementById('submit');status.className='status';status.textContent='جارٍ التحقق…';btn.disabled=true;try{const keys=[...box.querySelectorAll('textarea')].map(x=>x.value);if(pass.value.length!==30||keys.some(k=>k.length!==400))throw new Error('تأكد أن كلمة المرور 30 حرفاً وكل مفتاح 400 حرف.');const r=await fetch('/api/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pass.value,keys})});const data=await r.json();if(!r.ok)throw new Error(data.error||'فشل التحقق');status.className='status success';const a=document.createElement('a');a.href=data.rawUrl;a.target='_blank';a.rel='noopener';a.textContent=data.rawUrl;status.textContent='تم التحقق. رابط Raw صالح لمدة 5 دقائق: ';status.append(document.createElement('br'),a)}catch(err){status.className='status error';status.textContent=err.message||'تعذر التحقق.'}finally{btn.disabled=false}});
</script></body></html>`;

const encoder = new TextEncoder();
function b64url(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const raw = atob(s);
  return Uint8Array.from(raw, c => c.charCodeAt(0));
}
async function hmac(secret, data) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), {name:"HMAC", hash:"SHA-256"}, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(data)));
}
async function signPayload(payload, secret) {
  const body = b64url(encoder.encode(JSON.stringify(payload)));
  const mac = b64url(await hmac(secret, body));
  return `${body}.${mac}`;
}
async function validToken(token, secret) {
  if (!token || token.length > 2048) return false;
  const p = token.split(".");
  if (p.length !== 2) return false;
  const expected = b64url(await hmac(secret, p[0]));
  if (expected.length !== p[1].length) return false;
  let diff = 0; for (let i=0;i<expected.length;i++) diff |= expected.charCodeAt(i)^p[1].charCodeAt(i);
  if (diff !== 0) return false;
  try {
    const payload = JSON.parse(new TextDecoder().decode(unb64url(p[0])));
    return payload.scope === "raw" && payload.exp > Date.now();
  } catch { return false; }
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}});
}
function text(data, status=200) {
  return new Response(data, {status, headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store, max-age=0","X-Content-Type-Options":"nosniff"}});
}
async function handle(request, env) {
  const url = new URL(request.url);
  if (request.method === "GET" && url.pathname === "/") return new Response(HTML_GATE,{headers:{"Content-Type":"text/html; charset=utf-8"}});
  if (request.method === "GET" && url.pathname === "/unlock") return new Response(HTML_UNLOCK,{headers:{"Content-Type":"text/html; charset=utf-8"}});
  if (request.method === "GET" && url.pathname === "/health") return json({ok:true,service:"TRO API"});
  if (request.method === "POST" && url.pathname === "/api/verify") {
    if (!env.TRO_KV || !env.ACCESS_PASSWORD || !env.TOKEN_SECRET || env.TOKEN_SECRET.length < 32)
      return json({error:"إعداد السيرفر غير مكتمل. راجع إعدادات Worker وKV."},503);
    let body; try { body = await request.json(); } catch { return json({error:"طلب غير صالح."},400); }
    if (typeof body.password !== "string" || body.password.length !== 30 || body.password !== env.ACCESS_PASSWORD)
      return json({error:"كلمة المرور غير صحيحة."},401);
    if (!Array.isArray(body.keys) || body.keys.length !== 20) return json({error:"يجب إرسال 20 مفتاحاً."},400);
    for (let i=0;i<20;i++) {
      const stored = await env.TRO_KV.get(`gate:${i+1}`);
      if (!stored || typeof body.keys[i] !== "string" || body.keys[i].length !== 400 || body.keys[i] !== stored)
        return json({error:`المفتاح رقم ${i+1} غير صحيح أو لم تتم تهيئته.`},401);
    }
    const token = await signPayload({scope:"raw",exp:Date.now()+300000,nonce:b64url(crypto.getRandomValues(new Uint8Array(12)))},env.TOKEN_SECRET);
    return json({ok:true,rawUrl:`${url.origin}/api/raw?token=${encodeURIComponent(token)}`,expiresInSeconds:300});
  }
  if (request.method === "GET" && url.pathname === "/api/raw") {
    if (!env.TRO_KV || !env.TOKEN_SECRET) return text("TRO API is not configured.",503);
    if (!await validToken(url.searchParams.get("token"),env.TOKEN_SECRET)) return text("TRO: invalid or expired token.",401);
    const script = await env.TRO_KV.get("script.lua");
    if (script === null) return text("TRO: script.lua has not been added to KV.",404);
    return text(script);
  }
  return text("Not found",404);
}
export default { async fetch(request, env) { return handle(request, env); } };
