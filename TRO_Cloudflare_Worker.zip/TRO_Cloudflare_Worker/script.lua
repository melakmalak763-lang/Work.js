-- ضع هنا نص Lua الذي تملك حق نشره، ثم خزّنه في KV باسم script.lua
print("TRO API raw endpoint works")
