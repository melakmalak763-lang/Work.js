const crypto = require("crypto");
function makeKey() {
  let out = "";
  while (out.length < 400) out += crypto.randomBytes(320).toString("base64").replace(/[^A-Za-z0-9]/g, "");
  return out.slice(0, 400);
}
console.log(JSON.stringify(Array.from({ length: 20 }, makeKey), null, 2));
