const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...CORS_HEADERS }
  });
}

function b64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function fromB64url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}

async function hmacSign(secret, message) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message)));
}

async function issueToken(env, expiresAt) {
  const payload = b64url(new TextEncoder().encode(JSON.stringify({ exp: expiresAt, v: 1 })));
  const signature = b64url(await hmacSign(env.TRO_SIGNING_SECRET, payload));
  return payload + "." + signature;
}

async function validToken(env, token) {
  if (!token || !env.TRO_SIGNING_SECRET) return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const expected = b64url(await hmacSign(env.TRO_SIGNING_SECRET, parts[0]));
  if (expected.length !== parts[1].length) return false;
  let mismatch = 0;
  for (let i = 0; i < expected.length; i++) mismatch |= expected.charCodeAt(i) ^ parts[1].charCodeAt(i);
  if (mismatch !== 0) return false;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
    return payload.v === 1 && Number.isFinite(payload.exp) && payload.exp > Date.now();
  } catch {
    return false;
  }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    const url = new URL(request.url);

    if (url.pathname === "/health" && request.method === "GET") {
      return json({ ok: true, service: "TRO API", version: "1.0" });
    }

    if (url.pathname === "/api/verify" && request.method === "POST") {
      if (!env.TRO_PASSWORD || !env.TRO_KEYS_JSON || !env.TRO_SIGNING_SECRET || !env.SCRIPTS) {
        return json({ error: "الخادم غير مكتمل الإعداد." }, 503);
      }

      let body;
      try { body = await request.json(); }
      catch { return json({ error: "صيغة الطلب غير صحيحة." }, 400); }

      if (typeof body.password !== "string" || body.password.length !== 30) {
        return json({ error: "كلمة المرور يجب أن تكون 30 حرفاً." }, 400);
      }
      if (body.password !== env.TRO_PASSWORD) {
        return json({ error: "كلمة المرور غير صحيحة." }, 401);
      }
      if (!Array.isArray(body.keys) || body.keys.length !== 20 ||
          body.keys.some(k => typeof k !== "string" || k.length !== 400)) {
        return json({ error: "أرسل 20 مفتاحاً، طول كل واحد 400 حرف." }, 400);
      }

      let expectedKeys;
      try { expectedKeys = JSON.parse(env.TRO_KEYS_JSON); }
      catch { return json({ error: "إعداد المفاتيح في الخادم غير صالح." }, 503); }

      if (!Array.isArray(expectedKeys) || expectedKeys.length !== 20 ||
          !body.keys.every((key, i) => key === expectedKeys[i])) {
        return json({ error: "المفاتيح غير صحيحة." }, 401);
      }

      const token = await issueToken(env, Date.now() + 5 * 60 * 1000);
      return json({ ok: true, token, expiresIn: 300,
        rawUrl: `${url.origin}/api/raw?token=${encodeURIComponent(token)}` });
    }

    if (url.pathname === "/api/raw" && request.method === "GET") {
      if (!await validToken(env, url.searchParams.get("token"))) {
        return new Response("Unauthorized or expired token", {
          status: 401, headers: { "Content-Type": "text/plain; charset=utf-8", ...CORS_HEADERS }
        });
      }
      const script = await env.SCRIPTS.get("script.lua");
      if (script === null) {
        return new Response("Script not configured", {
          status: 404, headers: { "Content-Type": "text/plain; charset=utf-8", ...CORS_HEADERS }
        });
      }
      return new Response(script, {
        status: 200,
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          "Cache-Control": "no-store",
          "X-Content-Type-Options": "nosniff",
          ...CORS_HEADERS
        }
      });
    }

    return json({ error: "المسار غير موجود." }, 404);
  }
};
