-- ضع هنا سكربت Lua الذي تملكه أو لديك إذن بنشره.
print('TRO API script loaded as text')
